package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

@org.springframework.stereotype.Repository
public interface Repository extends JpaRepository<Entity, Long>{

	List<Entity> findAll();
	
	List<Entity> findAll(Specification<Entity> specification);
}
