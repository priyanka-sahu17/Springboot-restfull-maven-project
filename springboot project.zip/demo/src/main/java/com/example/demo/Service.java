package com.example.demo;

import java.util.List;
import java.util.Map;

public interface Service {

	public String createFreeListing(Bean bean);

	public List<Bean> getFreeListing();

	public List<Bean> searchCriteria(Map<String, String> data);

	
	
	

}
