package com.example.demo;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@org.springframework.web.bind.annotation.RestController
public class RestController {

	public final Service service;
	
	public RestController(Service service) {
		this.service = service;
	}
	
	@PostMapping("/createFreeListing")
	public String createFreeListing(@ModelAttribute("business") Bean bean) {
		
		return service.createFreeListing(bean);
	}
	
	@GetMapping("/getFreeListing")
	public List<Bean> getFreeListing(){
		System.out.println("insidde-----");
		
		return service.getFreeListing();
	}
	
	
	@PostMapping(value="/searchCriteria")
	public List<Bean> searchCriteria(@RequestBody Map<String, String> data){
		return service.searchCriteria(data);
	}
}
