package com.example.demo;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@javax.persistence.Entity
@Table(name="business_list",schema = "demodb")
public class Entity implements java.io.Serializable {

	private long businessId;
	private String firstName;
	private String lastName;
	private String companyName;
	private int state;
	private String mobileNumber;
	
	
	@Id
	@Column(name="business_Id",unique = true, nullable = false)
	@GenericGenerator(name = "bus_id", strategy = "increment")
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "bus_id")
	public long getBusinessId() {
		return businessId;
	}
	public void setBusinessId(long businessId) {
		this.businessId = businessId;
	}
	
	@Column(name="first_name",length=45)
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	@Column(name="last_name",length=45)
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	@Column(name="company_name",  length=11)
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	@Column(name="state",  length=11)
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
	@Column(name="mobile_number",  length=45)
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
 
	
	
}
