package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebControllerForViewJsp {

	
	@GetMapping("/demo")
	public String jspView() {
		
		return "index";
	}
	
	@GetMapping("/free-listing")
	public String freelisting(){
		
		return "free-listing";
	}
	
}
