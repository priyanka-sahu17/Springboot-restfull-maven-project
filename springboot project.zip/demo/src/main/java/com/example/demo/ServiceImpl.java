package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service{

	private List<Bean> list = new ArrayList<Bean>();
	private List<Bean> list1 = new ArrayList<Bean>();
	@Autowired Repository repo;
	
	@Override
	public String createFreeListing(Bean bean) {
		
		Entity entity = new Entity();
		entity.setCompanyName(bean.getCompanyName());
		entity.setState(bean.getState());
		entity.setMobileNumber(bean.getMobileNumber());
		entity.setFirstName(bean.getFirstName());
		entity.setLastName(bean.getLastName());
		
		repo.save(entity);
		
		
		return "success";
	}

	@Override
	public List<Bean> getFreeListing() {
		System.out.println("insidde-----");
		List<Entity> entitys = repo.findAll();
		System.out.println("size"+entitys.size());
		list.clear();
		for(Entity entity :entitys) {
			
			Bean bean = new Bean();
			bean.setBusinessId(entity.getBusinessId());
			bean.setCompanyName(entity.getCompanyName());
			bean.setFirstName(entity.getFirstName());
			bean.setLastName(entity.getLastName());
			bean.setMobileNumber(entity.getMobileNumber());
			bean.setState(entity.getState());
			list.add(bean);
		}
		
		return list;
	}

	@Override
	public List<Bean> searchCriteria(Map<String, String> data) {
		
		String searchId = data.get("searchId");
		System.out.println(searchId);
		List<Entity> entitys = null;
		if(null != searchId) {
			
			 entitys =  repo.findAll((Specification<Entity>) (root, cq, cb) -> {
				
				List<Predicate> list = new ArrayList<Predicate>();
				
				if(null != searchId) {
					list.add(cb.like(root.get("firstName"),   searchId ));
				}
				Predicate[] p = new Predicate[list.size()];
				return cb.and(list.toArray(p));
			});
			
		}
		list1.clear();	
          for(Entity entity :entitys) {
			
			Bean bean = new Bean();
			bean.setBusinessId(entity.getBusinessId());
			bean.setCompanyName(entity.getCompanyName());
			bean.setFirstName(entity.getFirstName());
			bean.setLastName(entity.getLastName());
			bean.setMobileNumber(entity.getMobileNumber());
			bean.setState(entity.getState());
			list1.add(bean);
		}
		

		
		
		
		return list1;
	}
	
	

}
